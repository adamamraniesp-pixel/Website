# Send consultation form answers to your Google Sheet

I can't write into your private Google Sheet directly (it needs your Google login),
but I've already wired the website's consultation form so that as soon as you plug in
one URL, every submission gets added as a new row automatically. This takes about
5 minutes, one time.

## Step 1 — Open the Apps Script editor on your sheet
1. Open your spreadsheet:
   https://docs.google.com/spreadsheets/d/19xKcjyNpewDr-bE_e_fFtNvdjsLNiGKeYnJdV_Fo3DU/edit
2. Click **Extensions → Apps Script**.
3. Delete anything in the editor and paste this in:

```javascript
function doPost(e) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
  var data = JSON.parse(e.postData.contents);

  // If the sheet is empty, add headers first
  if (sheet.getLastRow() === 0) {
    sheet.appendRow(["Timestamp", "Name", "Email", "Company", "Message"]);
  }

  sheet.appendRow([
    data.timestamp,
    data.name,
    data.email,
    data.company,
    data.message,
  ]);

  return ContentService
    .createTextOutput(JSON.stringify({ status: "success" }))
    .setMimeType(ContentService.MimeType.JSON);
}
```

4. Click the **Save** icon (disk icon), name the project something like
   "Consultation Form Logger".

## Step 2 — Deploy it as a Web App
1. Click **Deploy → New deployment**.
2. Click the gear icon next to "Select type" and choose **Web app**.
3. Set:
   - **Execute as:** Me
   - **Who has access:** Anyone
4. Click **Deploy**, then **Authorize access** and approve the permissions
   (it's your own script acting on your own sheet, so this is safe).
5. Copy the **Web app URL** it gives you — it looks like:
   `https://script.google.com/macros/s/AKfycb.../exec`

## Step 3 — Paste that URL into the website code
Open `src/routes/contact.tsx` and find this line near the top of the
`ConsultationForm` section:

```javascript
const SHEET_WEBHOOK_URL = "PASTE_YOUR_GOOGLE_APPS_SCRIPT_WEB_APP_URL_HERE";
```

Replace the placeholder text with the URL you copied in Step 2, keeping the quotes:

```javascript
const SHEET_WEBHOOK_URL = "https://script.google.com/macros/s/AKfycb.../exec";
```

Save, rebuild/redeploy your site, and you're done. From then on, every time
someone submits the "Start my application" form, a new row with their name,
email, company, and message will appear at the bottom of your sheet
automatically — in addition to the existing email notification.

## Notes
- If you ever change the sheet's structure or want submissions to go to a
  specific tab instead of whichever tab is currently active, let me know the
  tab name and I can adjust the script to target it directly
  (`SpreadsheetApp.getActiveSpreadsheet().getSheetByName("TabName")`).
- If you'd rather I set this up a different way (e.g., a real backend +
  Google Sheets API with a service account instead of Apps Script), that's
  possible too, but it requires creating a Google Cloud service account —
  more setup for the same result. Apps Script is the quickest reliable path.
