import { createFileRoute } from "@tanstack/react-router";
import { FinalCta, PageHeader, WhyZocalo } from "@/components/site/sections";

const title = "Why Zocalo — A Marketplace, Not a Single Lender";
const description =
  "One file, every lender in the panel. No cost unless you get funded, straight answers on rates, and no dead ends when a lender declines.";

export const Route = createFileRoute("/why-zocalo")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: WhyZocaloPage,
});

function WhyZocaloPage() {
  return (
    <>
      <PageHeader
        eyebrow="Why Zocalo"
        title="A wider path to approval"
        body="Not a single lender's yes-or-no. Access to a full commercial panel, matched to how your business actually qualifies."
      />
      <WhyZocalo heading={false} />
      <FinalCta />
    </>
  );
}
