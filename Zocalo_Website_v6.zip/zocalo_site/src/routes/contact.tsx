import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowUpRight, Check } from "lucide-react";
import { PageHeader } from "@/components/site/sections";
import { SectionFloaters } from "@/components/site/SectionFloaters";
import { useReducedMotion } from "@/components/site/motion";

const title = "Contact — Start Your Application | Zocalo";
const description =
  "Tell us about your business and funding need. Zocalo matches you across our commercial lender panel—free, confidential, no obligation.";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ContactPage,
});

const EASE = [0.16, 1, 0.3, 1] as const;

const expectations = [
  {
    n: "01",
    title: "A 30-minute funding review",
    meta: "~30 min",
    body: "We walk through your revenue, time in business, and what the capital is for.",
  },
  {
    n: "02",
    title: "A candid fit assessment",
    meta: "Same call",
    body: "Which products you're likely to qualify for, and which ones aren't worth pursuing.",
  },
  {
    n: "03",
    title: "A written funding outline",
    meta: "Within 2 days",
    body: "Products, likely terms, and next steps—yours to keep whether you move forward with us or not.",
  },
];

const fields = [
  { id: "name", label: "Name", type: "text", placeholder: "Jane Doe", required: true },
  { id: "email", label: "Email", type: "email", placeholder: "jane@company.com", required: true },
  { id: "company", label: "Company", type: "text", placeholder: "Company name", required: false },
] as const;

/** Input shell with an animated glow border on hover/focus. */
function FieldShell({
  htmlFor,
  label,
  children,
}: {
  htmlFor: string;
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div className="group">
      <label
        htmlFor={htmlFor}
        className="block text-[0.7rem] font-medium tracking-[0.16em] text-muted-foreground uppercase transition-colors duration-200 group-focus-within:text-primary"
      >
        {label}
      </label>
      <motion.div
        whileHover={{ y: -2 }}
        transition={{ type: "spring", stiffness: 300, damping: 22 }}
        className="focus-pulse relative mt-3 rounded-md transition-shadow duration-500 ease-out group-hover:shadow-[0_0_0_1px_#75A7DF,0_0_18px_-2px_color-mix(in_oklab,#75A7DF_55%,transparent)] group-focus-within:shadow-[0_0_0_1px_#75A7DF,0_0_22px_-2px_color-mix(in_oklab,#75A7DF_60%,transparent)]"
      >
        {children}
        <span
          aria-hidden
          className="pointer-events-none absolute bottom-0 left-0 h-px w-full origin-left scale-x-0 bg-gold transition-transform duration-500 ease-out group-focus-within:scale-x-100"
        />
      </motion.div>
    </div>
  );
}

// Google Apps Script "Web App" URL that appends each submission as a new row
// in the consultation-answers Google Sheet. See SHEET_SETUP.md for how to get this.
const SHEET_WEBHOOK_URL =
  "https://script.google.com/macros/s/AKfycbzv9KCgUYyXbdn7Ipw_9Mt2HzHKKJMCa6B5NMPSI0Up9H26RYx7UPQ6wa1D2zEeM5pTMA/exec";

function ConsultationForm() {
  const [values, setValues] = useState({ name: "", email: "", company: "", message: "" });
  const [sent, setSent] = useState(false);

  const sendToSheet = async () => {
    if (!SHEET_WEBHOOK_URL || SHEET_WEBHOOK_URL.startsWith("PASTE_")) return;
    try {
      // Apps Script web apps don't return CORS headers, so we fire-and-forget
      // with no-cors. The row is still appended even though we can't read the response.
      await fetch(SHEET_WEBHOOK_URL, {
        method: "POST",
        mode: "no-cors",
        headers: { "Content-Type": "text/plain;charset=utf-8" },
        body: JSON.stringify({
          timestamp: new Date().toISOString(),
          name: values.name,
          email: values.email,
          company: values.company,
          message: values.message,
        }),
      });
    } catch (err) {
      console.error("Failed to log submission to Google Sheet:", err);
    }
  };

  const inputCls =
    "w-full rounded-md border border-border bg-background/70 px-4 py-3 text-base text-foreground transition-colors duration-200 ease-out outline-none placeholder:text-muted-foreground/45 focus:border-gold";

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        setSent(true);
        void sendToSheet();
        window.setTimeout(() => {
          setValues({ name: "", email: "", company: "", message: "" });
        }, 650);
        window.setTimeout(() => setSent(false), 3200);
      }}
      className="space-y-6"
    >
      {fields.map((f, i) => (
        <motion.div
          key={f.id}
          initial={{ opacity: 0, y: 14 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.5 }}
          transition={{ duration: 0.55, delay: 0.1 + i * 0.08, ease: EASE }}
        >
          <FieldShell htmlFor={f.id} label={f.label}>
            <input
              id={f.id}
              name={f.id}
              type={f.type}
              required={f.required}
              placeholder={f.placeholder}
              value={values[f.id]}
              onChange={(e) => setValues((v) => ({ ...v, [f.id]: e.target.value }))}
              className={inputCls}
            />
          </FieldShell>
        </motion.div>
      ))}

      <motion.div
        initial={{ opacity: 0, y: 14 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.5 }}
        transition={{ duration: 0.55, delay: 0.34, ease: EASE }}
      >
        <FieldShell htmlFor="message" label="Brief message">
          <textarea
            id="message"
            name="message"
            rows={4}
            value={values.message}
            onChange={(e) => setValues((v) => ({ ...v, message: e.target.value }))}
            placeholder="A sentence or two about your business and what the funding is for."
            className={`${inputCls} resize-none leading-[1.7]`}
          />
        </FieldShell>
      </motion.div>

      <motion.button
        type="submit"
        whileHover={{ y: -2 }}
        whileTap={{ scale: 0.9, y: 3 }}
        transition={{ type: "spring", stiffness: 620, damping: 12, mass: 0.6 }}
        className="group inline-flex w-full items-center justify-center gap-2 rounded-md border border-[color-mix(in_oklab,var(--navy)_80%,black)] bg-navy px-7 py-4 text-sm font-medium tracking-[0.02em] text-white transition-[background-color,box-shadow] duration-200 ease-out hover:bg-[color-mix(in_oklab,var(--navy)_92%,black)] hover:shadow-[0_16px_36px_-18px_color-mix(in_oklab,var(--navy)_55%,transparent)]"
      >
        <AnimatePresence mode="wait" initial={false}>
          {sent ? (
            <motion.span
              key="sent"
              className="inline-flex items-center gap-2"
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.3, ease: EASE }}
            >
              <motion.span
                initial={{ scale: 0, rotate: -30 }}
                animate={{ scale: 1, rotate: 0 }}
                transition={{ type: "spring", stiffness: 380, damping: 18 }}
                className="inline-flex"
              >
                <Check className="size-4" />
              </motion.span>
              Request sent
            </motion.span>
          ) : (
            <motion.span
              key="idle"
              className="inline-flex items-center gap-2"
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.3, ease: EASE }}
            >
              Start my application
              <ArrowUpRight className="size-4 transition-transform duration-200 ease-out group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
            </motion.span>
          )}
        </AnimatePresence>
      </motion.button>

      <p className="text-xs leading-[1.7] text-muted-foreground">
        We reply within one business day. Prefer email?{" "}
        <a
          href="mailto:hello@zocalo.dev?subject=Start%20My%20Funding%20Application"
          className="text-foreground underline decoration-border underline-offset-4 transition-colors hover:decoration-primary"
        >
          hello@zocalo.dev
        </a>
      </p>
      <p className="text-xs leading-[1.7] text-muted-foreground">
        Prefer calling us? Call{" "}
        <a
          href="tel:+13865642601"
          className="text-foreground underline decoration-border underline-offset-4 transition-colors hover:decoration-primary"
        >
          +1 (386) 564-2601
        </a>
      </p>
    </form>
  );
}

function ContactPage() {
  const reduced = useReducedMotion();

  return (
    <>
      <PageHeader
        eyebrow="Contact"
        title="Let's find the right financing"
        body="Tell us about your business and what the funding is for. We'll show you what you qualify for."
      />

      <section className="section relative overflow-hidden border-t border-border pt-0 md:pt-0">
        <SectionFloaters variant="b" />
        <div className="container-x relative z-10">
          <div
            aria-hidden
            className="drift-field pointer-events-none absolute -inset-x-10 -inset-y-16 -z-10 opacity-70"
          />
          <div className="relative overflow-hidden rounded-lg border border-border bg-card/60">
            <div className="grid lg:grid-cols-[1.05fr_0.95fr]">
              {/* Left — value proposition and formal timeline */}
              <div className="border-b border-border p-8 md:p-14 lg:border-r lg:border-b-0">
                <motion.p
                  className="text-[0.7rem] font-medium tracking-[0.2em] text-muted-foreground uppercase"
                  initial={{ opacity: 0, x: -24 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true, amount: 0.6 }}
                  transition={{ duration: 0.6, ease: EASE }}
                >
                  What the consultation covers
                </motion.p>
                <motion.h2
                  className="mt-6 text-2xl leading-[1.18] font-medium tracking-display text-balance md:text-[2.1rem]"
                  initial={{ opacity: 0, x: -24 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true, amount: 0.5 }}
                  transition={{ duration: 0.6, delay: 0.1, ease: EASE }}
                >
                  A structured review before you submit a single document
                </motion.h2>
                <div className="mt-10 h-px w-full bg-border" />

                <ol className="mt-2">
                  {expectations.map((e, i) => (
                    <motion.li
                      key={e.n}
                      initial={{ opacity: 0, x: -28 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      viewport={{ once: true, amount: 0.5 }}
                      transition={{ duration: 0.6, delay: 0.18 + i * 0.12, ease: EASE }}
                    >
                      <motion.div
                        whileHover={{ x: 8 }}
                        transition={{ type: "spring", stiffness: 300, damping: 24 }}
                        className="group grid grid-cols-[2rem_1fr] items-start gap-4 border-b border-border py-7 last:border-b-0 md:gap-8"
                      >
                        <span className="pt-[0.4rem] text-right text-[0.7rem] font-light tracking-[0.22em] tabular-nums text-[#75A7DF] transition-opacity duration-500 group-hover:opacity-100 opacity-80">
                          {e.n}
                        </span>
                        <div>
                          <div className="flex flex-wrap items-baseline justify-between gap-x-6 gap-y-1">
                            <h3 className="relative inline-block text-base font-medium tracking-[-0.01em] md:text-lg">
                              {e.title}
                              <span
                                aria-hidden
                                className="absolute -bottom-1 left-0 h-px w-full origin-left scale-x-0 bg-[#75A7DF] transition-transform duration-500 ease-out group-hover:scale-x-100"
                              />
                            </h3>
                            <span className="text-[0.7rem] font-medium tracking-[0.14em] text-primary/80 uppercase">
                              {e.meta}
                            </span>
                          </div>
                          <p className="mt-2.5 max-w-md text-sm leading-[1.75] text-muted-foreground">
                            {e.body}
                          </p>
                        </div>
                      </motion.div>
                    </motion.li>
                  ))}
                </ol>
              </div>

              {/* Right — booking form with floating shape behind */}
              <div className="relative overflow-hidden bg-background/40 p-8 md:p-14">
                <motion.div
                  aria-hidden
                  className="pointer-events-none absolute -top-16 -right-16 h-64 w-64 rounded-full opacity-70"
                  style={{
                    background:
                      "radial-gradient(circle at 50% 50%, color-mix(in oklab, var(--primary) 26%, transparent), transparent 70%)",
                  }}
                  animate={reduced ? {} : { y: [0, 22, 0], x: [0, -14, 0], scale: [1, 1.08, 1] }}
                  transition={{ duration: 14, repeat: Infinity, ease: "easeInOut" }}
                />
                <motion.div
                  aria-hidden
                  className="pointer-events-none absolute -bottom-20 -left-10 h-52 w-52 rounded-full opacity-60"
                  style={{
                    background:
                      "radial-gradient(circle at 50% 50%, color-mix(in oklab, var(--gold) 18%, transparent), transparent 70%)",
                  }}
                  animate={reduced ? {} : { y: [0, -18, 0], x: [0, 16, 0] }}
                  transition={{ duration: 18, repeat: Infinity, ease: "easeInOut" }}
                />

                <div className="relative">
                  <motion.p
                    className="text-[0.7rem] font-medium tracking-[0.2em] text-muted-foreground uppercase"
                    initial={{ opacity: 0, x: 28 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true, amount: 0.6 }}
                    transition={{ duration: 0.6, ease: EASE }}
                  >
                    Request a call
                  </motion.p>
                  <motion.h2
                    className="mt-6 text-xl font-medium tracking-[-0.02em] md:text-2xl"
                    initial={{ opacity: 0, x: 32 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true, amount: 0.5 }}
                    transition={{ duration: 0.65, delay: 0.08, ease: EASE }}
                  >
                    Start your application
                  </motion.h2>
                  <div className="mt-8 mb-9 h-px w-full bg-border" />
                  <ConsultationForm />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
