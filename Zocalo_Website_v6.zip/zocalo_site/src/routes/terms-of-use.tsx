import { createFileRoute } from "@tanstack/react-router";
import { FinalCta, PageHeader } from "@/components/site/sections";
import { LegalContactBlock, LegalList, LegalSection } from "@/components/site/LegalSection";

const title = "Terms of Use | Zocalo";
const description =
  "The terms that govern your access to and use of the Zocalo website and related services.";

export const Route = createFileRoute("/terms-of-use")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: TermsOfUsePage,
});

function TermsOfUsePage() {
  return (
    <>
      <PageHeader eyebrow="Legal" title="Terms of Use" body="Effective Date: September 7, 2026" />
      <section className="px-6 pb-24 md:px-10">
        <div className="container-x max-w-3xl">
          <p className="text-base leading-[1.75] text-muted-foreground">
            These Terms of Use ("Terms") govern your access to and use of the Zocalo website and
            related services (collectively, the "Website").
          </p>
          <p className="mt-4 text-base leading-[1.75] text-muted-foreground">
            By accessing or using the Website, you agree to be bound by these Terms. If you do
            not agree with these Terms, please do not use the Website.
          </p>

          <LegalSection heading="1. About Zocalo">
            <p>
              Zocalo provides commercial finance-related services designed to help businesses
              explore potential financing opportunities.
            </p>
            <p>
              Zocalo may work with or refer businesses to third-party lenders, financing
              companies, financial institutions, brokers, or other financing providers.
            </p>
            <p>
              Zocalo does not guarantee that any business will qualify for financing, receive an
              offer, or obtain financing on any particular terms.
            </p>
          </LegalSection>

          <LegalSection heading="2. No Guarantee of Financing">
            <p>
              Submitting an inquiry, application, or other information through the Website does
              not guarantee financing approval.
            </p>
            <p>
              Any financing offer, approval, interest rate, fee, repayment term, loan amount, or
              other financing condition is determined by the applicable financing provider.
            </p>
            <p>Zocalo does not guarantee:</p>
            <LegalList
              items={[
                "Approval for financing",
                "A specific financing amount",
                "A specific interest rate",
                "A specific repayment term",
                "Funding within a particular timeframe",
                "That a financing product will be available to you",
                "That any financing option will be suitable for your business",
              ]}
            />
            <p>You are responsible for reviewing the terms of any financing offer before accepting it.</p>
          </LegalSection>

          <LegalSection heading="3. Information You Provide">
            <p>
              You agree that information you provide to Zocalo will be accurate, current, and
              complete to the best of your knowledge.
            </p>
            <p>You agree not to submit false, misleading, fraudulent, or unauthorized information.</p>
            <p>You are responsible for updating information when necessary.</p>
          </LegalSection>

          <LegalSection heading="4. Third-Party Financing Providers">
            <p>Zocalo may introduce or refer you to third-party financing providers.</p>
            <p>
              These providers operate independently from Zocalo and may have their own
              eligibility requirements, terms, fees, privacy policies, and agreements.
            </p>
            <p>
              Zocalo does not control the decisions, practices, products, or policies of
              third-party financing providers.
            </p>
            <p>Any agreement you enter into with a lender or financing provider is between you and that provider.</p>
          </LegalSection>

          <LegalSection heading="5. No Financial, Legal, or Tax Advice">
            <p>Information provided through the Website is for general informational purposes only.</p>
            <p>
              Nothing on the Website should be interpreted as legal, tax, accounting, investment,
              or other professional advice.
            </p>
            <p>
              You should consult an appropriately qualified professional regarding your
              individual business and financial circumstances.
            </p>
          </LegalSection>

          <LegalSection heading="6. Website Content">
            <p>
              We make reasonable efforts to provide useful and accurate information on the
              Website. However, we do not guarantee that all information is complete, accurate,
              current, or free from errors.
            </p>
            <p>
              We reserve the right to modify, update, suspend, or discontinue any portion of the
              Website at any time without notice.
            </p>
          </LegalSection>

          <LegalSection heading="7. Acceptable Use">
            <p>You agree not to:</p>
            <LegalList
              items={[
                "Use the Website for unlawful purposes.",
                "Submit fraudulent or misleading information.",
                "Attempt to gain unauthorized access to the Website or its systems.",
                "Interfere with the operation or security of the Website.",
                "Introduce malicious code, viruses, or other harmful material.",
                "Scrape, copy, reproduce, or exploit Website content without permission.",
                "Impersonate another person or business.",
                "Use the Website to violate the rights of another person or entity.",
              ]}
            />
          </LegalSection>

          <LegalSection heading="8. Intellectual Property">
            <p>
              All content on the Website, including text, graphics, logos, designs, images,
              trademarks, software, and other materials, is owned by or licensed to Zocalo unless
              otherwise stated.
            </p>
            <p>
              You may not reproduce, distribute, modify, publish, transmit, sell, or commercially
              exploit Website content without our prior written permission.
            </p>
          </LegalSection>

          <LegalSection heading="9. Communications">
            <p>
              If you provide your contact information, you agree that Zocalo may contact you
              regarding your inquiry, requested services, financing opportunities, or other
              business-related communications, subject to applicable law.
            </p>
            <p>You may opt out of marketing communications at any time.</p>
            <p>
              For text messages, you may generally opt out by replying <strong>STOP</strong>.
              Message and data rates may apply.
            </p>
          </LegalSection>

          <LegalSection heading="10. Disclaimer of Warranties">
            <p>
              To the maximum extent permitted by applicable law, the Website and its content are
              provided on an "AS IS" and "AS AVAILABLE" basis.
            </p>
            <p>
              Zocalo makes no warranties, express or implied, regarding the Website, its
              availability, accuracy, reliability, or suitability for any particular purpose.
            </p>
          </LegalSection>

          <LegalSection heading="11. Limitation of Liability">
            <p>
              To the maximum extent permitted by applicable law, Zocalo and its owners, officers,
              employees, affiliates, agents, and service providers will not be liable for any
              indirect, incidental, consequential, special, exemplary, or punitive damages
              arising from or related to your use of the Website or services.
            </p>
            <p>
              Nothing in these Terms is intended to exclude or limit liability that cannot
              legally be excluded or limited under applicable law.
            </p>
          </LegalSection>

          <LegalSection heading="12. Indemnification">
            <p>
              To the maximum extent permitted by applicable law, you agree to defend, indemnify,
              and hold harmless Zocalo and its owners, officers, employees, affiliates, agents,
              and service providers from claims, liabilities, damages, losses, costs, and
              expenses arising from:
            </p>
            <LegalList
              items={[
                "Your use of the Website.",
                "Your violation of these Terms.",
                "Your violation of applicable laws or regulations.",
                "Information you submit through the Website.",
                "Your violation of the rights of another person or entity.",
              ]}
            />
          </LegalSection>

          <LegalSection heading="13. Third-Party Links">
            <p>The Website may contain links to third-party websites or services.</p>
            <p>
              Zocalo does not control and is not responsible for the content, availability,
              security, or practices of third-party websites.
            </p>
            <p>Accessing third-party websites is at your own risk.</p>
          </LegalSection>

          <LegalSection heading="14. Termination">
            <p>
              Zocalo may suspend or terminate your access to the Website at any time if we
              believe you have violated these Terms or if necessary to protect the Website, our
              business, or other users.
            </p>
            <p>Provisions that by their nature should survive termination will remain in effect.</p>
          </LegalSection>

          <LegalSection heading="15. Governing Law">
            <p>
              These Terms will be governed by the laws of the jurisdiction in which Zocalo is
              organized, without regard to conflict-of-law principles, unless applicable law
              requires otherwise.
            </p>
            <p>
              Any dispute arising from these Terms or your use of the Website will be handled in
              accordance with applicable law.
            </p>
          </LegalSection>

          <LegalSection heading="16. Changes to These Terms">
            <p>We may modify these Terms from time to time.</p>
            <p>
              Updated Terms will be posted on the Website with a revised effective date. Your
              continued use of the Website after changes are posted constitutes acceptance of the
              updated Terms.
            </p>
          </LegalSection>

          <LegalSection heading="17. Contact">
            <p>If you have questions regarding these Terms of Use, please contact:</p>
            <LegalContactBlock />
          </LegalSection>
        </div>
      </section>
      <FinalCta />
    </>
  );
}
