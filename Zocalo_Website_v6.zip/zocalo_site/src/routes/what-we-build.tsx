import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/what-we-build")({
  beforeLoad: () => { throw redirect({ to: "/loan-products", statusCode: 301 }); },
});
