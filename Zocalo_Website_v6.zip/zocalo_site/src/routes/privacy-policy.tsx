import { createFileRoute } from "@tanstack/react-router";
import { FinalCta, PageHeader } from "@/components/site/sections";
import { LegalContactBlock, LegalList, LegalSection } from "@/components/site/LegalSection";

const title = "Privacy Policy | Zocalo";
const description =
  "How Zocalo collects, uses, discloses, and protects the personal and business information you provide to us.";

export const Route = createFileRoute("/privacy-policy")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: PrivacyPolicyPage,
});

function PrivacyPolicyPage() {
  return (
    <>
      <PageHeader
        eyebrow="Legal"
        title="Privacy Policy"
        body="Effective Date: September 7, 2026"
      />
      <section className="px-6 pb-24 md:px-10">
        <div className="container-x max-w-3xl">
          <p className="text-base leading-[1.75] text-muted-foreground">
            Zocalo ("Zocalo," "we," "us," or "our") respects your privacy and is committed to
            protecting the personal and business information you provide to us.
          </p>
          <p className="mt-4 text-base leading-[1.75] text-muted-foreground">
            This Privacy Policy explains how we collect, use, disclose, and protect information
            when you visit our website, use our services, submit a financing inquiry, or otherwise
            communicate with us.
          </p>
          <p className="mt-4 text-base leading-[1.75] text-muted-foreground">
            By accessing or using our website, you acknowledge the practices described in this
            Privacy Policy.
          </p>

          <LegalSection heading="1. Information We Collect">
            <p>We may collect information that you voluntarily provide to us, including:</p>
            <LegalList
              items={[
                "Full name",
                "Business name",
                "Email address",
                "Telephone number",
                "Business address",
                "Business type and industry",
                "Time in business",
                "Annual or monthly business revenue",
                "Requested financing amount",
                "Intended use of financing",
                "Business financial information",
                "Information about existing financing",
                "Information contained in documents you voluntarily submit",
                "Any other information you provide through forms, applications, emails, telephone calls, or other communications",
              ]}
            />
            <p>
              We may also automatically collect certain information when you visit our website,
              including:
            </p>
            <LegalList
              items={[
                "IP address",
                "Browser type",
                "Device information",
                "Operating system",
                "Pages visited",
                "Date and time of visits",
                "Referring websites",
                "General website usage information",
              ]}
            />
          </LegalSection>

          <LegalSection heading="2. How We Use Your Information">
            <p>We may use information we collect to:</p>
            <LegalList
              items={[
                "Respond to your inquiries.",
                "Understand your business financing needs.",
                "Evaluate potential financing opportunities.",
                "Facilitate financing inquiries and applications.",
                "Connect you with lenders, financing companies, brokers, or other financial service providers.",
                "Communicate with you about financing products and services.",
                "Provide information, quotes, or other services you request.",
                "Improve our website, products, and services.",
                "Prevent fraud, abuse, or unauthorized activity.",
                "Maintain records and comply with applicable laws and regulations.",
                "Send marketing communications where permitted by law.",
              ]}
            />
            <p>
              Submitting information to Zocalo does not guarantee that you will qualify for
              financing or receive an offer.
            </p>
          </LegalSection>

          <LegalSection heading="3. Sharing of Information">
            <p>
              We may share information you provide with third parties when reasonably necessary
              to provide our services or fulfill your request.
            </p>
            <p>These parties may include:</p>
            <LegalList
              items={[
                "Banks and lenders",
                "Commercial financing companies",
                "Financial institutions",
                "Financing brokers or referral partners",
                "Service providers that assist us with website hosting, technology, communications, analytics, or business operations",
                "Professional advisors",
                "Government authorities or law enforcement when required by law",
              ]}
            />
            <p>
              When you submit a financing inquiry, you authorize Zocalo to use and share the
              information reasonably necessary to evaluate your financing needs and connect you
              with potential financing providers.
            </p>
            <p>
              We do not sell your personal information for money as a general business practice.
              However, certain data-sharing activities may be considered "selling," "sharing," or
              targeted advertising under certain state privacy laws. Where applicable, we will
              provide legally required disclosures and choices.
            </p>
          </LegalSection>

          <LegalSection heading="4. Communications">
            <p>
              By providing your telephone number, email address, or other contact information,
              you may receive communications from Zocalo regarding your inquiry, financing
              opportunities, services, or related business matters.
            </p>
            <p>
              Depending on your preferences and applicable law, communications may include
              telephone calls, emails, and text messages.
            </p>
            <p>
              You may opt out of marketing communications at any time by following the
              unsubscribe instructions in an email or contacting us directly.
            </p>
            <p>
              For text messages, you may generally opt out by replying <strong>STOP</strong>.
              Message and data rates may apply. Consent to receive marketing communications is
              not a condition of purchasing any product or service.
            </p>
          </LegalSection>

          <LegalSection heading="5. Cookies and Tracking Technologies">
            <p>
              Our website may use cookies, pixels, analytics tools, and similar technologies to
              operate the website, understand visitor behavior, improve our services, and measure
              marketing performance.
            </p>
            <p>
              You may be able to control cookies through your browser settings. Disabling certain
              cookies may affect website functionality.
            </p>
          </LegalSection>

          <LegalSection heading="6. Third-Party Websites">
            <p>
              Our website may contain links to websites operated by third parties. Zocalo is not
              responsible for the privacy practices, content, or security of third-party
              websites.
            </p>
            <p>
              We encourage you to review the privacy policies of any third-party website you
              visit.
            </p>
          </LegalSection>

          <LegalSection heading="7. Data Security">
            <p>
              We use reasonable administrative, technical, and organizational safeguards designed
              to protect information against unauthorized access, disclosure, alteration, or
              destruction.
            </p>
            <p>
              However, no method of transmitting or storing information electronically is
              completely secure. We cannot guarantee the absolute security of your information.
            </p>
          </LegalSection>

          <LegalSection heading="8. Data Retention">
            <p>
              We may retain information for as long as reasonably necessary to provide our
              services, maintain business and financial records, resolve disputes, enforce
              agreements, prevent fraud, comply with legal obligations, and fulfill other
              legitimate business purposes.
            </p>
          </LegalSection>

          <LegalSection heading="9. Your Privacy Rights">
            <p>
              Depending on where you reside, you may have certain rights regarding your personal
              information, including the right to:
            </p>
            <LegalList
              items={[
                "Request access to certain personal information we maintain about you.",
                "Request correction of inaccurate information.",
                "Request deletion of certain information.",
                "Request information regarding how your information is collected or used.",
                "Opt out of certain forms of data sharing or targeted advertising where applicable.",
              ]}
            />
            <p>
              To submit a privacy-related request, contact us using the contact information
              provided on our website.
            </p>
            <p>We may need to verify your identity before completing certain requests.</p>
          </LegalSection>

          <LegalSection heading="10. Children's Privacy">
            <p>
              Our website and services are intended for businesses and adults. We do not
              knowingly collect personal information from children under the age of 13.
            </p>
            <p>
              If we become aware that we have collected information from a child under 13, we
              will take reasonable steps to delete it.
            </p>
          </LegalSection>

          <LegalSection heading="11. Changes to This Privacy Policy">
            <p>
              We may update this Privacy Policy from time to time. When we make changes, we will
              update the "Effective Date" at the top of this policy.
            </p>
            <p>
              Your continued use of the website after changes are posted constitutes
              acknowledgment of the updated Privacy Policy.
            </p>
          </LegalSection>

          <LegalSection heading="12. Contact Us">
            <p>
              If you have questions regarding this Privacy Policy or how Zocalo handles
              information, please contact us through the contact information provided on our
              website.
            </p>
            <LegalContactBlock />
          </LegalSection>
        </div>
      </section>
      <FinalCta />
    </>
  );
}
