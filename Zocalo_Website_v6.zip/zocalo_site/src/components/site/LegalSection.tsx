import type { ReactNode } from "react";

/** A single numbered/titled section within a legal document (Privacy Policy, Terms of Use). */
export function LegalSection({ heading, children }: { heading: string; children: ReactNode }) {
  return (
    <section className="mt-12 first:mt-0">
      <h2 className="text-xl font-medium tracking-display md:text-2xl">{heading}</h2>
      <div className="mt-4 space-y-4 text-base leading-[1.75] text-muted-foreground">{children}</div>
    </section>
  );
}

/** A bulleted list inside a LegalSection, styled to match the surrounding body copy. */
export function LegalList({ items }: { items: ReactNode[] }) {
  return (
    <ul className="list-disc space-y-2 pl-5">
      {items.map((item, i) => (
        <li key={i}>{item}</li>
      ))}
    </ul>
  );
}

/** The company contact block repeated at the end of both legal documents. */
export function LegalContactBlock() {
  return (
    <div className="not-italic">
      <p className="font-medium text-foreground">Zocalo</p>
      <p>1251 Fairfax Hunt, Lawrenceville, GA, 30043, USA</p>
      <p>Lawrenceville Georgia 30043</p>
      <p>+13865642601</p>
    </div>
  );
}
