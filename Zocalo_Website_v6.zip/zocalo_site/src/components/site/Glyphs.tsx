import type { CSSProperties } from "react";
import { motion } from "framer-motion";

type GlyphProps = { className?: string; style?: CSSProperties };

const base = "text-primary";
const stroke = {
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 1.7,
  strokeLinecap: "round" as const,
  strokeLinejoin: "round" as const,
};

/** Ringing handset with outbound signal arcs — after-hours answering. */
export function GlyphAnswering({ className, style }: GlyphProps) {
  return (
    <svg viewBox="0 0 96 64" className={`${base} ${className ?? ""}`} style={style} aria-hidden>
      <path d="M16 20c0 16 12 28 28 28" {...stroke} />
      <path d="M12 16h10l4 9-6 4" {...stroke} />
      <path d="M44 44v8h-8" {...stroke} />
      <path d="M60 22a14 14 0 0 1 0 20" {...stroke} opacity="0.75" />
      <path d="M70 15a24 24 0 0 1 0 34" {...stroke} opacity="0.45" />
      <path d="M80 8a34 34 0 0 1 0 48" {...stroke} opacity="0.38" />
      {/* idle: signal rings expanding on a loop */}
      <g className="idle-pulse">
        <circle cx="52" cy="32" r="10" {...stroke} />
        <circle cx="52" cy="32" r="18" {...stroke} />
        <circle cx="52" cy="32" r="26" {...stroke} />
      </g>
      <circle cx="52" cy="32" r="2" fill="currentColor" />

    </svg>
  );
}

/** Staged pipeline columns with a moving card — CRM. */
export function GlyphPipeline({ className, style }: GlyphProps) {
  return (
    <svg viewBox="0 0 96 64" className={`${base} ${className ?? ""}`} style={style} aria-hidden>
      <rect x="8" y="12" width="20" height="40" rx="2" {...stroke} opacity="0.5" />
      <rect x="34" y="12" width="20" height="40" rx="2" {...stroke} opacity="0.7" />
      <rect x="60" y="12" width="20" height="40" rx="2" {...stroke} />
      <rect x="12" y="18" width="12" height="7" rx="1.5" fill="currentColor" opacity="0.42" />
      <rect x="38" y="18" width="12" height="7" rx="1.5" fill="currentColor" opacity="0.45" />
      <rect x="64" y="18" width="12" height="7" rx="1.5" fill="currentColor" opacity="0.8" />
      <path d="M84 32h6M86 28l4 4-4 4" {...stroke} />
      {/* idle: card travelling across the pipeline stages */}
      <rect
        className="idle-packet"
        x="12"
        y="40"
        width="12"
        height="7"
        rx="1.5"
        fill="currentColor"
        opacity="0.9"
        style={{ ["--packet-distance" as never]: "52px" }}
      />

    </svg>
  );
}

/** Branching intake path with checkpoints — patient workflow. */
export function GlyphWorkflow({ className, style }: GlyphProps) {
  return (
    <svg viewBox="0 0 96 64" className={`${base} ${className ?? ""}`} style={style} aria-hidden>
      <motion.path
        d="M8 32h18"
        {...stroke}
        initial={{ pathLength: 0 }}
        whileInView={{ pathLength: 1 }}
        viewport={{ once: true, amount: 0.5 }}
        transition={{ duration: 0.5, ease: "easeOut" }}
      />
      <motion.path
        d="M26 32c10 0 10-16 20-16h14"
        {...stroke}
        opacity="0.8"
        initial={{ pathLength: 0 }}
        whileInView={{ pathLength: 1 }}
        viewport={{ once: true, amount: 0.5 }}
        transition={{ duration: 0.9, delay: 0.45, ease: "easeInOut" }}
      />
      <motion.path
        d="M26 32c10 0 10 16 20 16h14"
        {...stroke}
        opacity="0.6"
        initial={{ pathLength: 0 }}
        whileInView={{ pathLength: 1 }}
        viewport={{ once: true, amount: 0.5 }}
        transition={{ duration: 0.9, delay: 0.65, ease: "easeInOut" }}
      />
      <circle cx="26" cy="32" r="3.5" {...stroke} />
      <circle cx="62" cy="16" r="3.5" fill="currentColor" opacity="0.8" className="idle-breathe" />
      <circle cx="62" cy="48" r="3.5" {...stroke} opacity="0.6" />
      <path d="M68 16h20M68 48h14" {...stroke} opacity="0.52" />
      {/* idle: intake packet travelling into the branch */}
      <circle
        className="idle-packet"
        cx="10"
        cy="32"
        r="2"
        fill="currentColor"
        style={{ ["--packet-distance" as never]: "48px" }}
      />

    </svg>
  );
}

/** Sequential steps ascending — client onboarding. Draws itself in view. */
export function GlyphOnboarding({ className, style }: GlyphProps) {
  return (
    <svg viewBox="0 0 96 64" className={`${base} ${className ?? ""}`} style={style} aria-hidden>
      <path d="M8 8v44" {...stroke} opacity="0.42" />
      <motion.path
        d="M8 52h20V38h20V24h20"
        {...stroke}
        initial={{ pathLength: 0 }}
        whileInView={{ pathLength: 1 }}
        viewport={{ once: true, amount: 0.5 }}
        transition={{ duration: 1.4, ease: "easeInOut" }}
      />
      {[
        { cx: 28, cy: 38, d: 0.5 },
        { cx: 48, cy: 24, d: 0.9 },
        { cx: 68, cy: 24, d: 1.3 },
      ].map((p) => (
        <motion.circle
          key={p.cx}
          cx={p.cx}
          cy={p.cy}
          r="2.8"
          fill="currentColor"
          initial={{ opacity: 0, scale: 0.4 }}
          whileInView={{ opacity: [0, 0.9, 0.55, 0.9], scale: [0.4, 1.35, 1, 1.15] }}
          viewport={{ once: true, amount: 0.5 }}
          transition={{
            opacity: { duration: 2.4, delay: p.d, repeat: Infinity, repeatDelay: 0.6 },
            scale: { duration: 2.4, delay: p.d, repeat: Infinity, repeatDelay: 0.6 },
          }}
        />
      ))}
      <motion.path
        d="M68 24h20"
        {...stroke}
        opacity="0.52"
        initial={{ pathLength: 0 }}
        whileInView={{ pathLength: 1 }}
        viewport={{ once: true, amount: 0.5 }}
        transition={{ duration: 0.6, delay: 1.4, ease: "easeOut" }}
      />

    </svg>
  );
}

/** Plinth / base diagram used as the Why section's editorial mark. */
export function GlyphPlinth({ className, style }: GlyphProps) {
  return (
    <svg viewBox="0 0 120 80" className={`${base} ${className ?? ""}`} style={style} aria-hidden>
      <path d="M10 70h100" {...stroke} />
      <path d="M22 70V52h76v18" {...stroke} opacity="0.75" />
      <path d="M34 52V36h52v16" {...stroke} opacity="0.5" />
      <path d="M46 36V22h28v14" {...stroke} opacity="0.48" />
      <circle cx="60" cy="14" r="3" fill="currentColor" opacity="0.7" />
    </svg>
  );
}

/* ------------------------------ SERVICE GLYPHS ---------------------------- */

/** Nested blueprint frames converging on a core — bespoke engineering. */
export function GlyphBespoke({ className, style }: GlyphProps) {
  return (
    <svg viewBox="0 0 96 64" className={`${base} ${className ?? ""}`} style={style} aria-hidden>
      <rect x="8" y="8" width="80" height="48" rx="2" {...stroke} opacity="0.45" />
      <rect x="20" y="17" width="56" height="30" rx="2" {...stroke} opacity="0.55" />
      <rect x="34" y="25" width="28" height="14" rx="2" {...stroke} />
      <path d="M8 32h12M76 32h12M48 8v9M48 47v9" {...stroke} opacity="0.4" />
      <circle cx="48" cy="32" r="2.5" fill="currentColor" />
    </svg>
  );
}

/** Node-and-stage relationship graph — CRM systems. */
export function GlyphCrm({ className, style }: GlyphProps) {
  return (
    <svg viewBox="0 0 96 64" className={`${base} ${className ?? ""}`} style={style} aria-hidden>
      <path d="M14 32h20M46 32h18M46 18h18M46 46h18" {...stroke} opacity="0.5" />
      <path d="M34 32c6 0 6-14 12-14M34 32c6 0 6 14 12 14" {...stroke} opacity="0.7" />
      <circle cx="10" cy="32" r="4" {...stroke} />
      <circle cx="68" cy="18" r="3" fill="currentColor" opacity="0.85" />
      <circle cx="68" cy="32" r="3" fill="currentColor" opacity="0.55" />
      <circle cx="68" cy="46" r="3" fill="currentColor" opacity="0.48" />
      <path d="M74 18h14M74 32h10M74 46h6" {...stroke} opacity="0.48" />
    </svg>
  );
}

/** Decision diamond with automated branches — AI automation. */
export function GlyphAi({ className, style }: GlyphProps) {
  return (
    <svg viewBox="0 0 96 64" className={`${base} ${className ?? ""}`} style={style} aria-hidden>
      <path d="M6 32h18" {...stroke} opacity="0.6" />
      <path d="M38 32l12-12 12 12-12 12z" {...stroke} />
      <path d="M24 32h14" {...stroke} />
      <path d="M62 32h10c6 0 6-14 12-14" {...stroke} opacity="0.7" />
      <path d="M62 32h10c6 0 6 14 12 14" {...stroke} opacity="0.4" />
      <circle cx="50" cy="32" r="2.5" fill="currentColor" />
      <circle cx="88" cy="18" r="2.5" fill="currentColor" opacity="0.8" />
      <circle cx="88" cy="46" r="2.5" {...stroke} opacity="0.5" />
    </svg>
  );
}

/** Modular panel arrangement — internal platforms. */
export function GlyphPlatform({ className, style }: GlyphProps) {
  return (
    <svg viewBox="0 0 96 64" className={`${base} ${className ?? ""}`} style={style} aria-hidden>
      <rect x="8" y="10" width="34" height="20" rx="2" {...stroke} />
      <rect x="48" y="10" width="40" height="12" rx="2" {...stroke} opacity="0.55" />
      <rect x="48" y="26" width="40" height="28" rx="2" {...stroke} opacity="0.52" />
      <rect x="8" y="34" width="34" height="20" rx="2" {...stroke} opacity="0.7" />
      <path d="M14 18h14M14 42h20M54 34h26M54 42h18" {...stroke} opacity="0.45" />
    </svg>
  );
}

/** Browser frame with performance meter — websites. */
export function GlyphWebsite({ className, style }: GlyphProps) {
  return (
    <svg viewBox="0 0 96 64" className={`${base} ${className ?? ""}`} style={style} aria-hidden>
      <rect x="8" y="10" width="80" height="44" rx="3" {...stroke} opacity="0.6" />
      <path d="M8 20h80" {...stroke} opacity="0.6" />
      <circle cx="15" cy="15" r="1.5" fill="currentColor" opacity="0.7" />
      <path d="M18 44a22 22 0 0 1 44 0" {...stroke} />
      <path d="M40 44l14-11" {...stroke} />
      <circle cx="40" cy="44" r="2.5" fill="currentColor" />
      <path d="M70 44V30M78 44v-8" {...stroke} opacity="0.4" />
    </svg>
  );
}

/** Cross-connected endpoints — integrations. */
export function GlyphIntegration({ className, style }: GlyphProps) {
  return (
    <svg viewBox="0 0 96 64" className={`${base} ${className ?? ""}`} style={style} aria-hidden>
      <circle cx="16" cy="16" r="5" {...stroke} />
      <circle cx="16" cy="48" r="5" {...stroke} opacity="0.6" />
      <circle cx="80" cy="16" r="5" {...stroke} opacity="0.6" />
      <circle cx="80" cy="48" r="5" {...stroke} />
      <path d="M21 16h20M55 16h20M21 48h20M55 48h20" {...stroke} opacity="0.4" />
      <path d="M41 16c8 0 6 32 14 32M41 48c8 0 6-32 14-32" {...stroke} opacity="0.55" />
      <circle cx="48" cy="32" r="3" fill="currentColor" />
    </svg>
  );
}

/* ------------------------------ PROCESS GLYPHS ---------------------------- */

/** Concentric scan arcs around a central node — discovery. */
export function GlyphDiscover({ className, style }: GlyphProps) {
  return (
    <svg viewBox="0 0 120 80" className={className} style={style} aria-hidden>
      <circle cx="60" cy="40" r="3" fill="currentColor" />
      <circle cx="60" cy="40" r="12" {...stroke} opacity="0.8" />
      <path d="M60 40 88 22" {...stroke} />
      <path d="M82 40a22 22 0 0 0-22-22" {...stroke} opacity="0.6" />
      <path d="M94 40a34 34 0 0 0-34-34" {...stroke} opacity="0.4" />
      <path d="M106 40a46 46 0 0 0-46-46" {...stroke} opacity="0.38" />
      <path d="M14 40h34M60 52v22" {...stroke} opacity="0.48" />
      <circle cx="88" cy="22" r="2.5" fill="currentColor" opacity="0.85" />
      <circle cx="36" cy="58" r="2" fill="currentColor" opacity="0.5" />
    </svg>
  );
}

/** Wireframe sketch with a pointer — design. */
export function GlyphDesign({ className, style }: GlyphProps) {
  return (
    <svg viewBox="0 0 120 80" className={className} style={style} aria-hidden>
      <rect x="10" y="10" width="100" height="60" rx="2" {...stroke} opacity="0.45" />
      <path d="M10 24h100M40 24v46" {...stroke} opacity="0.5" />
      <rect x="48" y="32" width="34" height="8" rx="1.5" fill="currentColor" opacity="0.52" />
      <path d="M48 50h50M48 58h32" {...stroke} opacity="0.5" />
      <path d="M18 34h14M18 42h10M18 50h14" {...stroke} opacity="0.52" />
      <path d="M86 46l14 14-6 1-2 6-6-21z" {...stroke} />
      <circle cx="86" cy="46" r="2" fill="currentColor" />
    </svg>
  );
}

/** Layered production tiers shipped forward — build. */
export function GlyphBuild({ className, style }: GlyphProps) {
  return (
    <svg viewBox="0 0 120 80" className={className} style={style} aria-hidden>
      <rect x="12" y="52" width="56" height="16" rx="2" {...stroke} opacity="0.85" />
      <rect x="20" y="34" width="56" height="16" rx="2" {...stroke} opacity="0.6" />
      <rect x="28" y="16" width="56" height="16" rx="2" {...stroke} opacity="0.52" />
      <path d="M74 60h30M96 55l8 5-8 5" {...stroke} opacity="0.7" />
      <path d="M82 42h22M98 37l6 5-6 5" {...stroke} opacity="0.45" />
      <path d="M90 24h14" {...stroke} opacity="0.42" />
      <circle cx="20" cy="60" r="2" fill="currentColor" />
    </svg>
  );
}

/** Branching expansion with a feedback cycle — scale. */
export function GlyphScale({ className, style }: GlyphProps) {
  const rings = [16, 26, 36];
  return (
    <svg viewBox="0 0 120 80" className={className} style={style} aria-hidden>
      {/* expanding concentric node rings */}
      {rings.map((r, i) => (
        <motion.circle
          key={r}
          cx="52"
          cy="42"
          r={r}
          {...stroke}
          strokeWidth={0.9}
          initial={{ opacity: 0, scale: 0.6 }}
          whileInView={{ opacity: [0.15, 0.5, 0.15], scale: [0.85, 1.06, 0.85] }}
          viewport={{ once: false, amount: 0.4 }}
          transition={{
            duration: 4.4,
            delay: i * 0.5,
            repeat: Infinity,
            ease: "easeInOut",
          }}
          style={{ transformOrigin: "52px 42px" }}
        />
      ))}

      {/* glowing circular growth arrow */}
      <motion.g
        initial={{ pathLength: 0, opacity: 0 }}
        whileInView={{ pathLength: 1, opacity: 1 }}
        viewport={{ once: true, amount: 0.4 }}
        transition={{ duration: 1.3, ease: "easeInOut" }}
      >
        <motion.path
          d="M52 18a24 24 0 1 1-22 14.5"
          {...stroke}
          initial={{ pathLength: 0 }}
          whileInView={{ pathLength: 1 }}
          viewport={{ once: true, amount: 0.4 }}
          transition={{ duration: 1.4, ease: [0.16, 1, 0.3, 1] }}
        />
        <path d="M45 13.5 52 18l-4.5 7" {...stroke} />
      </motion.g>

      {/* orbiting node + satellite nodes */}
      <motion.circle
        cx="52"
        cy="42"
        r="4"
        fill="currentColor"
        animate={{ opacity: [0.55, 1, 0.55] }}
        transition={{ duration: 2.6, repeat: Infinity, ease: "easeInOut" }}
      />
      {[
        { x: 88, y: 22 },
        { x: 100, y: 46 },
        { x: 84, y: 64 },
      ].map((n, i) => (
        <g key={`${n.x}-${n.y}`}>
          <motion.path
            d={`M56 42 ${n.x} ${n.y}`}
            {...stroke}
            strokeWidth={0.9}
            initial={{ pathLength: 0, opacity: 0 }}
            whileInView={{ pathLength: 1, opacity: 0.55 }}
            viewport={{ once: true, amount: 0.4 }}
            transition={{ duration: 0.8, delay: 0.5 + i * 0.18, ease: "easeOut" }}
          />
          <motion.circle
            cx={n.x}
            cy={n.y}
            r="3"
            fill="currentColor"
            initial={{ scale: 0, opacity: 0 }}
            whileInView={{ scale: 1, opacity: 1 }}
            viewport={{ once: true, amount: 0.4 }}
            transition={{ duration: 0.5, delay: 0.9 + i * 0.18, ease: "backOut" }}
            style={{ transformOrigin: `${n.x}px ${n.y}px` }}
          />
        </g>
      ))}

      {/* rising baseline bars */}
      {[
        { x: 10, h: 12 },
        { x: 18, h: 20 },
        { x: 26, h: 30 },
      ].map((b, i) => (
        <motion.path
          key={b.x}
          d={`M${b.x} 74V${74 - b.h}`}
          {...stroke}
          strokeWidth={1.4}
          initial={{ pathLength: 0, opacity: 0 }}
          whileInView={{ pathLength: 1, opacity: 0.35 }}
          viewport={{ once: true, amount: 0.4 }}
          transition={{ duration: 0.6, delay: 0.3 + i * 0.14, ease: "easeOut" }}
        />
      ))}
    </svg>
  );
}
